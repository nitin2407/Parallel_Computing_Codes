g++ Assignment1.cpp
./a.out 10000 100
./a.out 100000 100
./a.out 1000000 100
