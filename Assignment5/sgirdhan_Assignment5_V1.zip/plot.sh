reset
set term png
set output out
plot inp with linespoints ls 1