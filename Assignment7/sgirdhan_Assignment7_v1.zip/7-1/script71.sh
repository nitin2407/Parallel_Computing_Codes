mpic++ -o par71 7-1.cpp
mpirun -n 32 ./par71
