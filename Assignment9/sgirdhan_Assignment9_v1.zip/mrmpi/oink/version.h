#define OINK_VERSION "7 Apr 2014"
